package checkers.client.main.model;

import checkers.client.main.util.Pair;

public class ProcessMove extends State {
    @Override
    public State select(Pair p) {
        // todo if (move finished) return new OtherMove(); else return this;
        return null;
    }
}
